

void initModbus(void);
void funcChargerStateMachine(void);