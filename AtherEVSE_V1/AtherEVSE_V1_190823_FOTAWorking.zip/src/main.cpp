#include <Arduino.h>

#ifndef _OTA_H_
  #define _OTA_H_
  #include "OTA.h"
#endif


void init_EspDetails(void)
{  
  log_i("SDK Version       = %s"  ,ESP.getSdkVersion());
  log_i("Chip Model        = %s"  ,ESP.getChipModel());  
  log_i("Chip Revision     = %d"  ,ESP.getChipRevision());  
  log_i("Chip Cores(#)     = %d"  ,ESP.getChipCores());
  log_i("CPU Freq(MHz)     = %d"  ,ESP.getCpuFreqMHz());  
  log_i("Flash Size(Bytes) = %d"  ,ESP.getFlashChipSize());  
  log_i("PSRAM Size(Bytes) = %d"  ,ESP.getPsramSize());
  log_i("Free PSRAM(Bytes) = %d"  ,ESP.getFreePsram());
  log_i("E Fuse/ChipId     = %lld",ESP.getEfuseMac());  
  log_i("FlashChipSpeed(Hz)= %d"  ,ESP.getFlashChipSpeed());   
  log_i("Flash Chip Mode   = %d"  ,ESP.getFlashChipMode());   
  log_i("Flash Chip Size   = %d"  ,ESP.getFlashChipSize());
  log_i("Heap Size (Bytes) = %d"  ,ESP.getHeapSize());
  log_i("Free Heap (Bytes) = %d"  ,ESP.getFreeHeap());
  log_i("FreeSketch(Bytes) = %d"  ,ESP.getFreeSketchSpace());
  log_i("Sketch Size(Bytes)= %d"  ,ESP.getSketchSize());     
  
}

void setup()
{
  Serial.begin(115200);
   
  log_i("|----------------System-Initializing----------------|");
  log_i("Serial Port Configured @115200");
  log_i("VERSION_NO = %d\n",VERSION_NO); // @OTA.h
  pinMode(SW3_PIN , INPUT_PULLUP); 
  delay(100);  

  init_EspDetails();
  init_Fota(1);


  log_i("Check for FOTA Update, Press Switch.....");
  log_i("Initializing.");
  
  for(int i1=0; i1<25; i1++)
  {
    Serial.print(".");
    delay(200);
  }

  
  if(!digitalRead(SW3_PIN))
  {
    log_i("Fota Pin Pressed....");
    delay(1000);
    if(!digitalRead(SW3_PIN))
    {
      log_i("Fota Pin Press Confirmed, Enable FOTA Task.....");
      func_FotaTrigger(1);       
    }
  }

  log_i("|----------------System-Initialized----------------|\n\n");
  delay(2000); 

  log_i("Setup Completed");
}

void loop()
{
  // TickType_t xLastWakeUpTime;
  // while(1)
  // {
  //   log_i("FOTA_TRIGGER_STATUS = %d\n",digitalRead(SW3_PIN));
  //   if(FOTA_TRIGGER_DETECTED)
  //   {
  //     vTaskDelay(pdMS_TO_TICKS(2000));
  //     if(FOTA_TRIGGER_DETECTED)
  //     {
  //       #if 1
  //       func_FotaTrigger(1);        
  //       #endif
  //     }
  //   }
  //   // vTaskDelay(pdMS_TO_TICKS(1000));
  //   vTaskDelayUntil(&xLastWakeUpTime,pdMS_TO_TICKS(1000));  
    
  // }

  delay(100);
}
