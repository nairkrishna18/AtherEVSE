#include "Adafruit_NeoPixel.h"

// Which pin on the Arduino is connected to the NeoPixels?
#define PIN        13 // for esp32 wrover kit

// How many NeoPixels are attached to the Arduino?
#define NUMPIXELS  16 // 8 //16 //8 // Popular NeoPixel ring size

// When setting up the NeoPixel library, we tell it how many pixels,
// and which pin to use to send signals. Note that for older NeoPixel
// strips you might need to change the third parameter -- see the
// strandtest example for more information on possible values.

void initNeoPixels(void);
void funcNeoPixel1(void);
void colorWipe(uint32_t c, uint8_t wait);
void mainNeoPixel(uint8_t animation);
uint32_t Wheel(byte WheelPos) ;
void rainbow(uint8_t wait);
void rainbowCycle(uint8_t wait) ;
void theaterChase(uint32_t color, int wait) ;
