

// void init_MFRC522(void);
// void fn_MFRC_Application(void);

// void fn_AuthenticateRFID(String sAUID);