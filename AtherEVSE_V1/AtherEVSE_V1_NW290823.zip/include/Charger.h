


/************************Trigger Pin or Point************************************/
#define FOTA_SWITCH                   (39)
#define FOTA_TRIGGER_DETECTED     (digitalRead(FOTA_SWITCH))
#define FOTA_TRIGGER_CLEARED      (!digitalRead(FOTA_SWITCH))
/*********************************************************************************/

// void funcChargerStateMachine(void);
void initCreateTask(void);

