// #include "MFRC522.h"

// //***************************MFRC Related Definitions********************************/
// #define RFID_RST_PIN    27 //15W//2NW //15W //14W //12NW //13W //16NW //17NW //0W //21W      // Configurable, see typical pin layout above
// #define SPI_RFID_CS     0//4W//17N//16N//5W       // Configurable, see typical pin layout above

// //String A_UID1 = "f9e4c814";
// String A_UID1 = "3da0fb"; // for RFID
// MFRC522 mfrc522(SPI_RFID_CS, RFID_RST_PIN);  // Create MFRC522 instance






// void fn_MFRC_Application(void)
// {
//    bool bnewCardStatus = mfrc522.PICC_IsNewCardPresent();
//   // Reset the loop if no new card present on the sensor/reader. This saves the entire process when idle.
// 	if ( !bnewCardStatus) {		
//     log_i("New Card Not Present!, Continue Scanning(%d)",bnewCardStatus);
// 		return;
// 	}
//   else
//   {
//     log_i("New Card Detected, Continue Scanning(%d)",bnewCardStatus);
//   }
	
//   bool breadCardStatus = mfrc522.PICC_ReadCardSerial();
// 	// Select one of the cards
// 	if ( !breadCardStatus) {
//     log_w("Cannot Read New Card!, Continue Scanning(%d)",breadCardStatus);
// 		return;
// 	}
// 	// Dump debug info about the card; PICC_HaltA() is automatically called
// 	mfrc522.PICC_DumpToSerial(&(mfrc522.uid));

//   // mfrc522.PICC_ReadCardSerial();

// }

// void fn_AuthenticateRFID(String sAUID)
// {
//   log_i("Lets Detect and Authorize RFID Card");
//   if (mfrc522.PICC_IsNewCardPresent()) 
//   {
//     log_i("New Card Detecte...");
//     #if 1
//           Serial.print(F("PICC type: "));
//           MFRC522::PICC_Type piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
//           Serial.println(mfrc522.PICC_GetTypeName(piccType));

//           // Check for compatibility
//           if (    piccType != MFRC522::PICC_TYPE_MIFARE_MINI
//               &&  piccType != MFRC522::PICC_TYPE_MIFARE_1K
//               &&  piccType != MFRC522::PICC_TYPE_MIFARE_4K) 
//             {
//               Serial.println(F("This sample only works with MIFARE Classic cards."));
//               delay(5000);
//               // return;
//             }
//         #endif
    
//     if (mfrc522.PICC_ReadCardSerial()) 
//     {
//       log_i("Reading Card Data...");
//       String strID = "";
//       for (byte i = 0; i < 4; i++) 
//       {
//         strID += String(mfrc522.uid.uidByte[i], HEX);
//       }
      
//       Serial.print("Card UID = ");
//       Serial.println(strID);     
      
//       // if (strID == "12345678") 
//       // if (strID == "f9e4c814") 
//       if (strID == sAUID) 
//       {  // Replace with your card UID
//         // Serial.println("Authorized access");
//         log_i("Authorized Access ....");     

        
//          delay(5000);

//       } 
//       else 
//       {
//         // Serial.println("Access denied");  
//          log_i("Access Denied !!!!");
//          delay(5000);

//       }
//     } 
//     else
//     {
//       log_i("Failed to read Card Data!!!");
//     }
//   }
//   else
//   {
//     log_i("No Cards Detected, Try Again...");
//   }
// }



