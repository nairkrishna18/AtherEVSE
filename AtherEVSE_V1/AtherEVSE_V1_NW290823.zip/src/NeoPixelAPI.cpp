#include "NeoPixelAPI.h"

const int interval = 200;
unsigned long previousMillis = 0;
static int8_t PixelCounter;
static uint16_t PixelBrightnessCntr;
int           pixelQueue = 0;           // Pattern Pixel Queue

// Parameter 1 = number of pixels in strip
// Parameter 2 = Arduino pin number (most are valid)
// Parameter 3 = pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
//   NEO_RGBW    Pixels are wired for RGBW bitstream (NeoPixel RGBW products)
Adafruit_NeoPixel pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

void initNeoPixels(void)
{
  pixels.begin(); // INITIALIZE NeoPixel strip object (REQUIRED)
  pixels.setBrightness(100); // set brightness levels globally.
  pixels.show();   // Send the updated pixel colors to the hardware. S
}


void mainNeoPixel(uint8_t animation)
{
  switch(animation)
  {
    case 0:
      // funcNeoPixel1();
      theaterChase(pixels.Color(0, 255, 0), 50); // Blue
      // Serial.print("funcNeoPixel1()");
    break;

    case 1:
      colorWipe(pixels.Color(0, 0, 255), 50); // Red
      // Serial.print("colorWipe()");
    break;

    case 2:
      rainbow(20);
      // Serial.print("rainbow()");
    break;

    case 3:
      rainbowCycle(2);
      // Serial.print("rainbowCycle()");
    break;
  }
  // 
  

}
void funcNeoPixel1(void)
{  
  if (millis() - previousMillis >= interval) 
  {
    previousMillis = millis();
    #if 1
      PixelCounter++;
      if(PixelCounter >= NUMPIXELS) // Display Number of pixels to be animated 
      {
        pixels.clear(); // Set all pixel colors to 'off'
        PixelCounter = -1; // so that all pixels are clear including 1st Pixel......
      }        
      // Serial.print("Pixel Number = ");
      // Serial.println(PixelCounter); 
      pixels.setPixelColor((PixelCounter), pixels.Color(255, 255, 255));
      pixels.show();   // Send the updated pixel colors to the hardware. 
    #else // to get the current consumption........
      PixelCounter++;
      if(PixelCounter >= NUMPIXELS) // Display Number of pixels to be animated 
      {
        // pixels.clear(); // Set all pixel colors to 'off'
        PixelCounter = 0; // so that all pixels are clear including 1st Pixel......
      }
      pixels.setPixelColor((PixelCounter), pixels.Color(255, 255, 255));
      pixels.show();   // Send the updated pixel colors to the hardware. 
    #endif
    }
}

// Theater-marquee-style chasing lights. Pass in a color (32-bit value,
// a la strip.Color(r,g,b) as mentioned above), and a delay time (in ms)
// between frames.
void theaterChase(uint32_t color, int wait)  // Not working need testing more
{
  static uint16_t pixNum, PixBright;
  if (millis() - previousMillis >= wait) 
  {
    previousMillis = millis();
    for(int i = 0; i < pixels.numPixels(); i++) 
    {
      pixels.setPixelColor(i + pixelQueue, color); //  Set pixel's color (in RAM)
    }
    pixels.show();                             //  Update strip to match
    for(int i=0; i < pixels.numPixels(); i+=3) 
    {
      pixels.setPixelColor(i + pixelQueue, pixels.Color(0, 0, 0)); //  Set pixel's color (in RAM)
    }
    pixelQueue++;                             //  Advance current pixel
    if(pixelQueue >= 3)
    {
       pixelQueue = 0;                         //  Loop the pattern from the first LED
    }    
  } 
}

void rainbow(uint8_t wait) 
{
  static uint16_t pixNum, PixBright;

  if (millis() - previousMillis >= wait) 
  {
    previousMillis = millis();
    PixBright++; // Update Pixel brightness Value 0 to 255
    // Serial.print("PixBright = ");
    // Serial.println(PixBright);
    
    if(PixBright <= 255) // Display Number of pixels to be animated 
    {
      for(pixNum=0; pixNum<pixels.numPixels(); pixNum++) // pixels number from 0 to numPixels....
      {
        // Serial.print("pixNum = ");
        // Serial.println(pixNum);
        pixels.setPixelColor(pixNum, Wheel((pixNum + PixBright) & 255));
      }
      pixels.show();      
    }   
    else
    {
      PixBright = 0; 
    }    
  }
}

void rainbowCycle(uint8_t wait) 
{
 
  static uint16_t pixNum, PixBright;

  if (millis() - previousMillis >= wait) 
  {
    previousMillis = millis();
    PixBright++; // Update Pixel brightness Value 0 to 255
    // Serial.print("PixBright = ");
    // Serial.println(PixBright);
    
    if(PixBright <= 255*5) // Display Number of pixels to be animated 
    {
      for(pixNum=0; pixNum<pixels.numPixels(); pixNum++) // pixels number from 0 to numPixels....
      {
        // Serial.print("pixNum = ");
        // Serial.println(pixNum);
        pixels.setPixelColor(pixNum, Wheel(((pixNum * 256 / pixels.numPixels()) + PixBright) & 255));
      }
      pixels.show();      
    }   
    else
    {
      PixBright = 0; 
    }    
  }
}

#if 0 // not implemented yet, may be later if required...........
//Theatre-style crawling lights with rainbow effect
void theaterChaseRainbow(uint8_t wait) 
{
  for (int j=0; j < 256; j++) // 0 to 255
  {     // cycle all 256 colors in the wheel
    for (int q=0; q < 3; q++) // 0,1,2
    {
      for (uint16_t i=0; i < strip.numPixels(); i=i+3) // 0 to Num Pixels
      {
        strip.setPixelColor(i+q, Wheel( (i+j) % 255));    //turn every third pixel on
      }
      strip.show();

      delay(wait);

      for (uint16_t i=0; i < strip.numPixels(); i=i+3) 
      {
        strip.setPixelColor(i+q, 0);        //turn every third pixel off
      }
    }
  }
}
#endif


// Fill the dots one after the other with a color
void colorWipe(uint32_t c, uint8_t wait) 
{
  
  if (millis() - previousMillis >= wait) 
  {
    previousMillis = millis();
    PixelCounter++;
    if(PixelCounter >= pixels.numPixels()) // Display Number of pixels to be animated 
    {
      pixels.clear(); // Set all pixel colors to 'off'
      PixelCounter = -1; // so that all pixels are clear including 1st Pixel......
    }    
    pixels.setPixelColor(PixelCounter, c);
    pixels.show();
  }
  
}




// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t Wheel(byte WheelPos) 
{
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) 
  {
    return pixels.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  }
  if(WheelPos < 170) 
  {
    WheelPos -= 85;
    return pixels.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return pixels.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
