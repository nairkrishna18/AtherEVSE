


#include "RFID_API.h"
#include <EEPROM.h>     // We are going to read and write PICC's UIDs from/to EEPROM
#include "GlobalHeader.h"

//Constants
#define EEPROM_SIZE 50 //12

#define wipeB       2    // Button pin for WipeMode

bool programMode = false;  // initialize programming mode to false

uint8_t successRead;    // Variable integer to keep if we have Successful Read from Reader

byte storedCard[4];   // Stores an ID read from EEPROM
byte readCard[4];   // Stores scanned ID read from RFID Module
byte masterCard[4];   // Stores master card's ID read from EEPROM

MFRC522 mfrc522(SS_PIN, RST_PIN);  // Create MFRC522 instance

uint8_t ShowReaderDetails(void) ; 
void init_Rfid_WipeCode(void);
void initCheckUpdateMasterCardStatus(void);

//String A_UID1 = "f9e4c814";
// String A_UID1 = "3da0fb"; // for RFID
// String A_UID2 = "92A3C1"; //"92A3C11C"; // for RFID
// String A_UID3 = "39D9F7"; //"39D9F7A2"; // for RFID


uint8_t initRFID(void)
{
    gNeoPixelState = NP_CW_BLANK;
    uint8_t retStatus = 0;
    //Init EEPROM
    EEPROM.begin(EEPROM_SIZE);
    log_i("Initialized and Configured EEPROM, Size --> %d Bytes", EEPROM_SIZE);

    // put your setup code here, to run once:
    pinMode(wipeB, INPUT_PULLUP);   // Enable pin's pull up resistor

    log_i("Initializing MFRC522 Reader....");

    SPI.begin();			// Init SPI bus
    mfrc522.PCD_Init();		// Init MFRC522
    delay(4);				// Optional delay. Some board do need more time after init to be ready, see Readme    
    
    #if 0 //If you set Antenna Gain to Max it will increase reading distance    
      mfrc522.PCD_SetAntennaGain(mfrc522.RxGain_max);
    #endif

    #if 1
      retStatus = ShowReaderDetails();
    #else
      mfrc522.PCD_DumpVersionToSerial();	// Show details of PCD - MFRC522 Card Reader details
      Serial.println(F("Scan PICC to see UID, SAK, type, and data blocks..."));
    #endif

    if(retStatus) // Reader is Ok.........
    {      
      init_Rfid_WipeCode();
      initCheckUpdateMasterCardStatus();
    }

  return retStatus;
}

void fn_RFIDApplication(void)
{
    #if 1
  // Reset the loop if no new card present on the sensor/reader. This saves the entire process when idle.
	if ( ! mfrc522.PICC_IsNewCardPresent()) {
		return;
	}
	// Select one of the cards
	if ( ! mfrc522.PICC_ReadCardSerial()) {
		return;
	}
	// Dump debug info about the card; PICC_HaltA() is automatically called
	mfrc522.PICC_DumpToSerial(&(mfrc522.uid));
    #endif
}

void fn_AuthenticateRFID(String sAUID)
{
  log_v("Lets Detect and Authorize RFID Card");
  if (mfrc522.PICC_IsNewCardPresent()) 
  {
    log_i("New Card Detected...");
    #if 1
          Serial.print(F("PICC type: "));
          MFRC522::PICC_Type piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
          Serial.println(mfrc522.PICC_GetTypeName(piccType));

          // Check for compatibility
          if (    piccType != MFRC522::PICC_TYPE_MIFARE_MINI
              &&  piccType != MFRC522::PICC_TYPE_MIFARE_1K
              &&  piccType != MFRC522::PICC_TYPE_MIFARE_4K) 
            {
              Serial.println(F("This sample only works with MIFARE Classic cards."));
              delay(5000);
              // return;
            }
    #endif
    
    if (mfrc522.PICC_ReadCardSerial()) 
    {
      log_i("Reading Card Data...");
      String strID = "";
      for (byte i = 0; i < 4; i++) 
      {
        strID += String(mfrc522.uid.uidByte[i], HEX);
      }
      
      Serial.print("Card UID = ");
      Serial.println(strID);     
      
      // if (strID == "12345678") 
      // if (strID == "f9e4c814") 
      if (strID == sAUID) 
      {  // Replace with your card UID
        // Serial.println("Authorized access");
        log_i("Authorized Access ....");     

        
         delay(5000);

      } 
      else 
      {
        // Serial.println("Access denied");  
         log_i("Access Denied !!!!");
         delay(5000);

      }
    } 
    else
    {
      log_i("Failed to read Card Data!!!");
    }
  }
  else
  {
    log_v("No Cards Detected, Try Again...");
  }
}

// return 1 if sucess...................
// return 0 if failed to recognize reader.........
uint8_t ShowReaderDetails(void) 
{
  uint8_t retStatus = 0;
  // Get the MFRC522 software version
  byte v = mfrc522.PCD_ReadRegister(mfrc522.VersionReg);
  log_i("MFRC522 Software Version: 0x%x ", v);

  if (v == 0x91)
  {
    log_i(" Version = 1.0 ");
    retStatus = 1;
  }
  else if (v == 0x92)
  {
    log_i(" Version = 2.0 ");
    retStatus = 1;
  }
  else
  {
      log_e("Unknown Verison! --> Probably a chinese clone?");
  }
  
  // When 0x00 or 0xFF is returned, communication probably failed
  if ((v == 0x00) || (v == 0xFF)) 
  {
    log_w("WARNING: Communication failure, is the MFRC522 properly connected?");
    log_e("SYSTEM HALTED: Check connections.");
    // Visualize system is halted
   
   // Note: Disabled in FreeRTOS, we cannot hold it here...................
   // while (true); // do not go further
  }
  return retStatus;
}

bool monitorWipeButton(uint32_t interval) 
{
  uint32_t now = (uint32_t)millis();
  while ((uint32_t)millis() - now < interval)  
  {
    // check on every half a second
    if (((uint32_t)millis() % 500) == 0) 
    {
      if (digitalRead(wipeB) != LOW)
        return false;
    }
  }
  return true;
}

void init_Rfid_WipeCode(void)
{
  #if 1
  //Wipe Code - If the Button (wipeB) Pressed while setup run (powered on) it wipes EEPROM
  if (digitalRead(wipeB) == LOW) 
  {  // when button pressed pin should get low, button connected to ground
    
    log_i("Wipe Button Pressed");
    log_i("You have 10 seconds to Cancel");
    log_i("This will be remove all records and cannot be undone");
    
    gNeoPixelState = NP_CW_RED_10SEC;
    
    #if 0 // Non Blocking delay cannot use in init loop....
      bool buttonState = monitorWipeButton(10000); // Give user enough time to cancel operation
      if (buttonState == true && digitalRead(wipeB) == LOW)  
    #else // Blocking delay used in init loop..........
      vTaskDelay(pdMS_TO_TICKS(10000)); // delay of 10s is created.
    #endif
    if (digitalRead(wipeB) == LOW) 
    {    // If button still be pressed, wipe EEPROM
      log_i("Starting Wiping EEPROM");

      gNeoPixelState = NP_CW_MAGENTA;
      
      for (uint16_t x = 0; x < EEPROM.length(); x = x + 1) 
      {    //Loop end of EEPROM address
        if (EEPROM.read(x) == 0) 
        {              //If EEPROM address 0
          // do nothing, already clear, go to the next address in order to save time and reduce writes to EEPROM
        }
        else 
        {
          EEPROM.write(x, 0);       // if not write 0 to clear, it takes 3.3mS
        }
      }
      log_i("EEPROM Successfully Wiped");
      EEPROM.commit();
    }
    else 
    {
      log_i("Wiping Cancelled"); // Show some feedback that the wipe button did not pressed for 15 seconds
      
    }
  } /// End of Wipe Routine
  #endif
}

uint8_t getID() 
{
  // Getting ready for Reading PICCs
  if ( ! mfrc522.PICC_IsNewCardPresent()) 
  { //If a new PICC placed to RFID reader continue
    return 0;
  }
  if ( ! mfrc522.PICC_ReadCardSerial()) 
  {   //Since a PICC placed get Serial and continue
    return 0;
  }
  // There are Mifare PICCs which have 4 byte or 7 byte UID care if you use 7 byte PICC
  // I think we should assume every PICC as they have 4 byte UID
  // Until we support 7 byte PICCs
  Serial.println(F("Scanned PICC's UID:"));
  for ( uint8_t i = 0; i < 4; i++) 
  {  //
    readCard[i] = mfrc522.uid.uidByte[i];
    Serial.print(readCard[i], HEX);
  }
  Serial.println("");

  mfrc522.PICC_HaltA(); // Stop reading
  return 1;
}

void initCheckUpdateMasterCardStatus(void)
{
  // Check if master card defined, if not let user choose a master card
  // This also useful to just redefine the Master Card
  // You can keep other EEPROM records just write other than 143 to EEPROM address 1
  // EEPROM address 1 should hold magical number which is '143'

  int MagicNumber1 = EEPROM.read(1);
  Serial.print("MagicNumber1(EE) = ");
  Serial.println(MagicNumber1);
  
  if (EEPROM.read(1) != 143) 
  {
    Serial.println(F("No Master Card Defined"));
    Serial.println(F("Scan A PICC to Define as Master Card"));
    do {
      successRead = getID();            // sets successRead to 1 when we get read from reader otherwise 0
//      digitalWrite(blueLed, LED_ON);    // Visualize Master Card need to be defined
      delay(200);
//      digitalWrite(blueLed, LED_OFF);
      delay(200);
    }
    while (!successRead);                  // Program will not go further while you not get a successful read
    for ( uint8_t j = 0; j < 4; j++ ) 
    {        // Loop 4 times
      EEPROM.write( 2 + j, readCard[j] );  // Write scanned PICC's UID to EEPROM, start from address 3
      delay(10);
      
    }
    EEPROM.write(1, 143);                  // Write to EEPROM we defined Master Card.
    delay(100);
    EEPROM.commit();
    
    Serial.println(F("Master Card Defined"));
    int MagicNumber2 = EEPROM.read(20);
    Serial.print("MagicNumber2(EE) = ");
    Serial.println(MagicNumber2);
  } // Check Master Card Defined Status ends here..........

  Serial.println(F("-------------------"));
  Serial.println(F("Master Card's UID"));
  for ( uint8_t i = 0; i < 4; i++ ) 
  {          // Read Master Card's UID from EEPROM
    masterCard[i] = EEPROM.read(2 + i);    // Write it to masterCard
    Serial.print(masterCard[i], HEX);
  }
  Serial.println("");
  Serial.println(F("-------------------"));
  Serial.println(F("Everything is ready"));
  Serial.println(F("Waiting PICCs to be scanned"));
}

void funcCheckUpdateMasterCardStatus(void)
{
  //  do
  {
    successRead = getID();  // sets successRead to 1 when we get read from reader otherwise 0
    // When device is in use if wipe button pressed for 10 seconds initialize Master Card wiping
    if (digitalRead(wipeB) == LOW) 
    { // Check if button is pressed
      // Visualize normal operation is iterrupted by pressing wipe button Red is like more Warning to user
      // digitalWrite(redLed, LED_ON);  // Make sure led is off
      // digitalWrite(greenLed, LED_OFF);  // Make sure led is off
      // digitalWrite(blueLed, LED_OFF); // Make sure led is off
      // Give some feedback
      log_i("Wipe Button Pressed");
      log_i("Master Card will be Erased! in 10 seconds");
      #if 0 // Non Blocking delay cannot use in init loop....
      bool buttonState = monitorWipeButton(10000); // Give user enough time to cancel operation
      if (buttonState == true && digitalRead(wipeB) == LOW)  
    #else // Blocking delay used in init loop..........
      vTaskDelay(pdMS_TO_TICKS(10000)); // delay of 10s is created.
    #endif

      if (digitalRead(wipeB) == LOW) 
      {    // If button still be pressed, wipe EEPROM
        EEPROM.write(1, 0);                  // Reset Magic Number.
        
        log_i("Master Card Erased from device");
        log_i("Please reset to re-program Master Card");
        EEPROM.commit();
        // while (1);
      }
      log_i("Master Card Erase Cancelled");
    }
    if (programMode) 
    {
      // cycleLeds();              // Program Mode cycles through Red Green Blue waiting to read a new card
      // log_w("Add Code for cycle Led using NeoPixel.......");
    }
    else 
    {
      // normalModeOn();     // Normal mode, blue Power LED is on, all others are off
      // log_w("Add Code for Normal Mode Led using NeoPixel.......");
    }
    
  }
  // while (!successRead);   //the program will not go further while you are not getting a successful read

}

///////////////////////////////////////// Check Bytes   ///////////////////////////////////
bool checkTwo ( byte a[], byte b[] ) 
{   
  for ( uint8_t k = 0; k < 4; k++ ) 
  {   // Loop 4 times
    if ( a[k] != b[k] ) 
    {     // IF a != b then false, because: one fails, all fail
       return false;
    }
  }
  return true;  
}
////////////////////// Check readCard IF is masterCard   ///////////////////////////////////
// Check to see if the ID passed is the master programing card
bool isMaster( byte test[] ) 
{
  return checkTwo(test, masterCard);
}

//////////////////////////////////////// Read an ID from EEPROM //////////////////////////////
void readID( uint8_t number ) 
{
  uint8_t start = (number * 4 ) + 2;    // Figure out starting position
  for ( uint8_t i = 0; i < 4; i++ ) 
  {     // Loop 4 times to get the 4 Bytes
    storedCard[i] = EEPROM.read(start + i);   // Assign values read from EEPROM to array
  }
}


///////////////////////////////////////// Find ID From EEPROM   ///////////////////////////////////
bool findID( byte find[] ) 
{
  uint8_t count = EEPROM.read(0);     // Read the first Byte of EEPROM that
  for ( uint8_t i = 1; i < count; i++ ) 
  {    // Loop once for each EEPROM entry
    readID(i);          // Read an ID from EEPROM, it is stored in storedCard[4]
    if ( checkTwo( find, storedCard ) ) 
    {   // Check to see if the storedCard read from EEPROM
      return true;
    }
    else 
    {    // If not, return false
      
    }
  }
  return false;
}

//////////////////////////////////////// Success Remove UID From EEPROM  ///////////////////////////////////
// Flashes the blue LED 3 times to indicate a success delete to EEPROM
void successDelete() 
{
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // digitalWrite(redLed, LED_OFF);  // Make sure red LED is off
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
  // delay(200);
  // digitalWrite(blueLed, LED_ON);  // Make sure blue LED is on
  // delay(200);
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // delay(200);
  // digitalWrite(blueLed, LED_ON);  // Make sure blue LED is on
  // delay(200);
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // delay(200);
  // digitalWrite(blueLed, LED_ON);  // Make sure blue LED is on
  // delay(200);
}


///////////////////////////////////////// Write Failed to EEPROM   ///////////////////////////////////
// Flashes the red LED 3 times to indicate a failed write to EEPROM
void failedWrite() 
{
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // digitalWrite(redLed, LED_OFF);  // Make sure red LED is off
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
  // delay(200);
  // digitalWrite(redLed, LED_ON);   // Make sure red LED is on
  // delay(200);
  // digitalWrite(redLed, LED_OFF);  // Make sure red LED is off
  // delay(200);
  // digitalWrite(redLed, LED_ON);   // Make sure red LED is on
  // delay(200);
  // digitalWrite(redLed, LED_OFF);  // Make sure red LED is off
  // delay(200);
  // digitalWrite(redLed, LED_ON);   // Make sure red LED is on
  // delay(200);
}
///////////////////////////////////////// Write Success to EEPROM   ///////////////////////////////////
// Flashes the green LED 3 times to indicate a successful write to EEPROM
void successWrite() 
{
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // digitalWrite(redLed, LED_OFF);  // Make sure red LED is off
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is on
  // delay(200);
  // digitalWrite(greenLed, LED_ON);   // Make sure green LED is on
  // delay(200);
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
  // delay(200);
  // digitalWrite(greenLed, LED_ON);   // Make sure green LED is on
  // delay(200);
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
  // delay(200);
  // digitalWrite(greenLed, LED_ON);   // Make sure green LED is on
  // delay(200);
}
///////////////////////////////////////// Find Slot   ///////////////////////////////////
uint8_t findIDSLOT( byte find[] ) 
{
  uint8_t count = EEPROM.read(0);       // Read the first Byte of EEPROM that
  for ( uint8_t i = 1; i <= count; i++ ) 
  {    // Loop once for each EEPROM entry
    readID(i);                // Read an ID from EEPROM, it is stored in storedCard[4]
    if ( checkTwo( find, storedCard ) ) 
    {   // Check to see if the storedCard read from EEPROM
      // is the same as the find[] ID card passed
      return i;         // The slot number of the card
    }
  }
}

///////////////////////////////////////// Remove ID from EEPROM   ///////////////////////////////////
void deleteID( byte a[] ) 
{
  if ( !findID( a ) ) 
  {     // Before we delete from the EEPROM, check to see if we have this card!
    failedWrite();      // If not
    Serial.println(F("Failed! There is something wrong with ID or bad EEPROM"));
  }
  else 
  {
    uint8_t num = EEPROM.read(0);   // Get the numer of used spaces, position 0 stores the number of ID cards
    uint8_t slot;       // Figure out the slot number of the card
    uint8_t start;      // = ( num * 4 ) + 6; // Figure out where the next slot starts
    uint8_t looping;    // The number of times the loop repeats
    uint8_t j;
    uint8_t count = EEPROM.read(0); // Read the first Byte of EEPROM that stores number of cards
    slot = findIDSLOT( a );   // Figure out the slot number of the card to delete
    start = (slot * 4) + 2;
    looping = ((num - slot) * 4);
    num--;      // Decrement the counter by one
    EEPROM.write( 0, num );   // Write the new count to the counter
    for ( j = 0; j < looping; j++ ) 
    {         // Loop the card shift times
      EEPROM.write( start + j, EEPROM.read(start + 4 + j));   // Shift the array values to 4 places earlier in the EEPROM
    }
    for ( uint8_t k = 0; k < 4; k++ ) 
    {         // Shifting loop
      EEPROM.write( start + j + k, 0);
    }
    successDelete();
    Serial.println(F("Succesfully removed ID record from EEPROM"));
    EEPROM.commit();
  }
}
///////////////////////////////////////// Add ID to EEPROM   ///////////////////////////////////
void writeID( byte a[] ) 
{
  if ( !findID( a ) ) 
  {     // Before we write to the EEPROM, check to see if we have seen this card before!
    uint8_t num = EEPROM.read(0);     // Get the numer of used spaces, position 0 stores the number of ID cards
    uint8_t start = ( num * 4 ) + 6;  // Figure out where the next slot starts
    num++;                // Increment the counter by one
    EEPROM.write( 0, num );     // Write the new count to the counter
    for ( uint8_t j = 0; j < 4; j++ ) 
    {   // Loop 4 times
      EEPROM.write( start + j, a[j] );  // Write the array values to EEPROM in the right position
    }
    successWrite();
    Serial.println(F("Succesfully added ID record to EEPROM"));
    EEPROM.commit();
  }
  else 
  {
    failedWrite();
    Serial.println(F("Failed! There is something wrong with ID or bad EEPROM"));
  }
}

/////////////////////////////////////////  Access Granted    ///////////////////////////////////
void granted ( uint16_t setDelay) 
{
  // digitalWrite(blueLed, LED_OFF);   // Turn off blue LED
  // digitalWrite(redLed, LED_OFF);  // Turn off red LED
  // digitalWrite(greenLed, LED_ON);   // Turn on green LED
//  digitalWrite(relay, LOW);     // Unlock door!
Serial.println("Unlocked Door!......");
  
  delay(setDelay);          // Hold door lock open for given seconds
//  digitalWrite(relay, HIGH);    // Relock door
  Serial.println("Relocked Door!......");
  delay(1000);            // Hold green LED on for a second
}

///////////////////////////////////////// Access Denied  ///////////////////////////////////
void denied() 
{
  // digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
  // digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
  // digitalWrite(redLed, LED_ON);   // Turn on red LED
  delay(1000);
}

void funcRFID_ProgramAndNormalMode(uint8_t __successRead)
{
  if(__successRead)
  {
    if (programMode) 
    {
      if ( isMaster(readCard) ) 
      { //When in program mode check First If master card scanned again to exit program mode
        Serial.println(F("Master Card Scanned"));
        Serial.println(F("Exiting Program Mode"));
        Serial.println(F("-----------------------------"));
        programMode = false;
        return;
      }
      else 
      {
        if ( findID(readCard) ) 
        { // If scanned card is known delete it
          Serial.println(F("I know this PICC, removing..."));
          deleteID(readCard);
          Serial.println("-----------------------------");
          Serial.println(F("Scan a PICC to ADD or REMOVE to EEPROM"));
        }
        else 
        {                    // If scanned card is not known add it
          Serial.println(F("I do not know this PICC, adding..."));
          writeID(readCard);
          Serial.println(F("-----------------------------"));
          Serial.println(F("Scan a PICC to ADD or REMOVE to EEPROM"));
        }
      }
    }
    else 
    {
      if ( isMaster(readCard)) 
      {    // If scanned card's ID matches Master Card's ID - enter program mode
        programMode = true;
        Serial.println(F("Hello Master - Entered Program Mode"));
        uint8_t count = EEPROM.read(0);   // Read the first Byte of EEPROM that
        Serial.print(F("I have "));     // stores the number of ID's in EEPROM
        Serial.print(count);
        Serial.print(F(" record(s) on EEPROM"));
        Serial.println("");
        Serial.println(F("Scan a PICC to ADD or REMOVE to EEPROM"));
        Serial.println(F("Scan Master Card again to Exit Program Mode"));
        Serial.println(F("-----------------------------"));
      }
      else 
      {
        if ( findID(readCard) ) 
        { // If not, see if the card is in the EEPROM
          Serial.println(F("Welcome, You shall pass"));
          granted(300);         // Open the door lock for 300 ms
        }
        else 
        {      // If not, show that the ID was not valid
          Serial.println(F("You shall not pass"));
          denied();
        }
      }
    }
  }

}

void funcRFIDAuthorize(void)
{

  funcCheckUpdateMasterCardStatus();
  funcRFID_ProgramAndNormalMode(successRead);
 

}