#include<Arduino.h> // included to identify  uint16_t..........

extern uint16_t gNeoPixelState;

enum 
{ 
    NP_CW_BLANK, 
    NP_CW_RED,
    NP_CW_GREEN,
    NP_CW_BLUE,
    NP_CW_YELLOW,
    NP_CW_CYAN,
    NP_CW_MAGENTA,
    NP_CW_WHITE,
    NP_CW_RED_10SEC, // used in Wait time for User Authentication........

    NP_RESET_PIXELS, // to clear all pixels and reset..
    
}; // anonymous enum (no name tag)